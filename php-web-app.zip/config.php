
<?php
$servername = "localhost";
$username = "root";   // default username
$password = "pass123"; // replace with your password
$dbname = "webapp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
